# PPID Disnav Samarinda – GitHub Pages (Tailwind)

## Cara Deploy
1. Buat repository publik, misal `ppid-disnav-samarinda`.
2. Unggah semua file/folder dari ZIP ini ke cabang `main`.
3. Aktifkan GitHub Pages: Settings → Pages → Deploy from a branch → `main` (root `/`).
4. Situs akan tersedia di `https://username.github.io/ppid-disnav-samarinda/`.

## Struktur
- `profil/` — profil, tugas & fungsi, visi-misi, struktur, regulasi, kontak
- `informasi/` — berkala, serta-merta, setiap-saat, dikecualikan
- `prosedur/` — alur permohonan informasi
- `assets/js/` — `nav.js`, `search.js`
- `assets/img/` — `logo-disnav.png` (gantikan dengan logo resmi)
- `assets/regulasi/` — taruh PDF regulasi

## Pencarian
- Data diambil dari `index.json`. Setiap tambah halaman, tambahkan entri di file ini.

## Domain Kustom (opsional)
- Buat berkas `CNAME` berisi `ppid.disnavsamarinda.my.id` **setelah** DNS CNAME diarahkan ke `username.github.io`.
